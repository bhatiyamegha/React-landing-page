import styled from 'styled-components';

export const Container = styled.div`
  display: grid;
  place-items: center;
  width: 100vw;
  min-height: 100vh;
  margin: 0;
`;

