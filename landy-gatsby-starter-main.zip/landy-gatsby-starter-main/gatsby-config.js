module.exports = {
  siteMetadata: {
    title: `Landy-Gatsby-Starter`,
    description: `Landy is a free React landing page template designed for developers and startups.`,
  },
  plugins: ["gatsby-plugin-react-helmet"],
}